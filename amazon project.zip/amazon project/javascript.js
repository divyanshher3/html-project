let slidebtnleft = document.getElementById("slider-btn-left")
let slidebtnright = document.getElementById("slider-btn-right")
let imageitem = document.querySelectorAll(".contaner-list")
console.log(imageitem.length-1)
let startslider =0
let endslider =(imageitem.length-1) *100 //700
slidebtnleft.addEventListener("click",()=>{
    if (startslider <0){
        startslider= startslider+100;
    }
     
     imageitem.forEach(Element=>{
        Element.style.transform= `translatex(${startslider}%)` ;
     })
})
slidebtnright.addEventListener("click",()=>{
    //  alert("right btn")
    if (startslider >= -endslider+100){
        startslider= startslider-100;
    }
     
     imageitem.forEach(Element=>{
        Element.style.transform= `translatex(${startslider}%)` ;
     })
     
})
